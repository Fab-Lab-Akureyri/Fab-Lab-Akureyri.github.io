#include <WiFi.h>
#include <HTTPClient.h>
#include <Adafruit_NeoPixel.h>

// WiFi credentials
const char* ssid = "FabLab";
const char* password = "Password01";

// LED setup
#define LED_PIN    21
#define LED_COUNT  13
Adafruit_NeoPixel strip(LED_COUNT, LED_PIN, NEO_GRB + NEO_KHZ800);
int brightness = 10;

// API URL
const char* url = "https://api.coingecko.com/api/v3/simple/price?ids=bitcoin&vs_currencies=usd";

// Price tracking
float lastPrice = 0;

void setColor(int r, int g, int b) {
  strip.fill(strip.Color(r, g, b));
  strip.show();
}

void setup() {
  Serial.begin(9600);

  strip.begin();
  strip.clear();
  strip.show();

  Serial.println("Connecting to WiFi...");
  WiFi.begin(ssid, password);

  while (WiFi.status() != WL_CONNECTED) {
    delay(500);
    Serial.print(".");
  }

  Serial.println("\nConnected!");
  Serial.print("IP: ");
  Serial.println(WiFi.localIP());
}

void loop() {
  if (WiFi.status() == WL_CONNECTED) {

    HTTPClient http;
    http.begin(url);

    int httpCode = http.GET();

    if (httpCode == 200) {
      String payload = http.getString();

      // --- VERY SIMPLE parsing ---
      int index = payload.indexOf("usd");
      int start = payload.indexOf(":", index) + 1;
      int end = payload.indexOf("}", start);

      float price = payload.substring(start, end).toFloat();

      Serial.print("Price: ");
      Serial.println(price);

      // Compare with last price
      if (lastPrice == 0) {
        // First reading → show blue
        Serial.println("FIRST READING → BLUE");
        setColor(0, 0, brightness);
      }
      else {
        if (price > lastPrice) {
          Serial.println("UP → GREEN");
          setColor(0, brightness, 0);
        }
        else if (price < lastPrice) {
          Serial.println("DOWN → RED");
          setColor(brightness, 0, 0);
        }
        else {
          Serial.println("SAME");
        }
      }

      lastPrice = price;
    }
    else {
      Serial.print("Error: ");
      Serial.println(httpCode);
    }

    http.end();
  }

  delay(30000); // wait 30 seconds
}