#include <WiFi.h>
#include <WebServer.h>
#include <Adafruit_NeoPixel.h>

// WiFi credentials
const char* ssid = "FabLab";
const char* password = "Password01";

// LED setup
#define LED_PIN    21
#define LED_COUNT  13
Adafruit_NeoPixel strip(LED_COUNT, LED_PIN, NEO_GRB + NEO_KHZ800);
int brightness = 10;

// Button setup
#define BUTTON_PIN 20
int lastButtonState = HIGH;
int buttonCount = 0;

// Web server
WebServer server(80);

// ----------- Helper: Set LED color -----------
void setColor(int r, int g, int b) {
  strip.fill(strip.Color(r, g, b));
  strip.show();
}

// ----------- Webpage -----------
void handleRoot() {
  String html = R"rawliteral(
  <!DOCTYPE html>
  <html>
  <head>
    <title>ESP32 Control</title>
  </head>
  <body>
    <h2>LED Control</h2>

    <button onclick="send('red')">Red</button>
    <button onclick="send('green')">Green</button>
    <button onclick="send('blue')">Blue</button>
    <button onclick="send('off')">Off</button>

    <h3>Button Status:</h3>
    <p id="status">Loading...</p>

    <h3>Button Count:</h3>
    <p id="count">0</p>

    <script>
      function send(color) {
        fetch('/set?color=' + color);
      }

      function update() {
        fetch('/status')
          .then(response => response.json())
          .then(data => {
            document.getElementById('status').innerText = data.pressed;
            document.getElementById('count').innerText = data.count;
          });
      }

      setInterval(update, 500);
    </script>
  </body>
  </html>
  )rawliteral";

  server.send(200, "text/html", html);
}

// ----------- Handle LED control -----------
void handleSet() {
  String color = server.arg("color");

  if (color == "red") {
    setColor(brightness, 0, 0);
  } else if (color == "green") {
    setColor(0, brightness, 0);
  } else if (color == "blue") {
    setColor(0, 0, brightness);
  } else if (color == "off") {
    setColor(0, 0, 0);
  }

  server.send(200, "text/plain", "OK");
}

// ----------- Send button status -----------
void handleStatus() {
  int buttonState = digitalRead(BUTTON_PIN);

  String pressedText = (buttonState == LOW) ? "Pressed" : "Not pressed";

  String json = "{";
  json += "\"pressed\":\"" + pressedText + "\",";
  json += "\"count\":" + String(buttonCount);
  json += "}";

  server.send(200, "application/json", json);
}

// ----------- Setup -----------
void setup() {
  Serial.begin(9600);

  pinMode(BUTTON_PIN, INPUT_PULLUP);

  strip.begin();
  strip.clear();
  strip.show();

  Serial.println("Connecting to WiFi...");
  WiFi.begin(ssid, password);

  while (WiFi.status() != WL_CONNECTED) {
    delay(500);
    Serial.print(".");
  }

  Serial.println("\nConnected!");
  Serial.print("IP: ");
  Serial.println(WiFi.localIP());

  // Web routes
  server.on("/", handleRoot);
  server.on("/set", handleSet);
  server.on("/status", handleStatus);

  server.begin();
}

// ----------- Loop -----------
void loop() {
  server.handleClient();

  // Button click detection
  int currentButtonState = digitalRead(BUTTON_PIN);

  if (lastButtonState == HIGH && currentButtonState == LOW) {
    buttonCount++;
    Serial.print("Button count: ");
    Serial.println(buttonCount);
  }

  lastButtonState = currentButtonState;

  delay(20);
}