#include <Adafruit_NeoPixel.h>

#define LED_PIN    21
#define LED_COUNT  13
#define BUTTON_PIN 20

Adafruit_NeoPixel strip(LED_COUNT, LED_PIN, NEO_GRB + NEO_KHZ800);

int lastButtonState = HIGH;
int currentLed = 0;

void setup() {
  Serial.begin(9600);

  pinMode(BUTTON_PIN, INPUT_PULLUP);

  strip.begin();
  strip.clear();

  // Turn on the first LED in blue
  strip.setPixelColor(currentLed, strip.Color(0, 0, 10));
  strip.show();
}

void loop() {
  int currentButtonState = digitalRead(BUTTON_PIN);

  // Detect a click
  if (lastButtonState == HIGH && currentButtonState == LOW) {
    currentLed = currentLed + 1;
    currentLed = currentLed % LED_COUNT;

    Serial.print("Current LED: ");
    Serial.println(currentLed);

    strip.clear();
    strip.setPixelColor(currentLed, strip.Color(0, 0, 10));
    strip.show();
  }

  lastButtonState = currentButtonState;

  delay(50);
}