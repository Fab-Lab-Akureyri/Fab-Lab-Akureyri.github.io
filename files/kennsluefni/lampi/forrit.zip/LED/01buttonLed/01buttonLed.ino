#include <Adafruit_NeoPixel.h>

#define LED_PIN    21
#define LED_COUNT  4

Adafruit_NeoPixel strip(LED_COUNT, LED_PIN, NEO_GRB + NEO_KHZ800);

void setup() {
  Serial.begin(9600);

  strip.begin();
  strip.show(); // turn all LEDs off
}

void loop() {
  Serial.println("RED");
  strip.fill(strip.Color(50, 0, 0));
  strip.show();
  delay(1000);

  Serial.println("GREEN");
  strip.fill(strip.Color(0, 50, 0));
  strip.show();
  delay(1000);

  Serial.println("BLUE");
  strip.fill(strip.Color(0, 0, 50));
  strip.show();
  delay(1000);

  Serial.println("waiting");
  strip.clear();
  strip.show();
  delay(3000);
}