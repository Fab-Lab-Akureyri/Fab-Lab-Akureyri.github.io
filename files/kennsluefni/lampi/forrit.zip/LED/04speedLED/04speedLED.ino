#include <Adafruit_NeoPixel.h>

#define LED_PIN    21
#define LED_COUNT  13
#define BUTTON_PIN 20

Adafruit_NeoPixel strip(LED_COUNT, LED_PIN, NEO_GRB + NEO_KHZ800);

int currentLed = 0;
int ledBrightness = 10;

// Speed settings
int slowDelay = 500;
int fastDelay = 20;
int fullSpeedTime = 10000;

// Time tracking
unsigned long buttonPressStart = 0;
unsigned long lastMoveTime = 0;

void setup() {
  Serial.begin(9600);

  pinMode(BUTTON_PIN, INPUT_PULLUP);

  strip.begin();
  strip.clear();

  // Start with first LED blue
  strip.setPixelColor(currentLed, strip.Color(0, 0, ledBrightness));
  strip.show();
}

void loop() {
  int buttonState = digitalRead(BUTTON_PIN);

  if (buttonState == LOW) {
    // Button is being held

    if (buttonPressStart == 0) {
      buttonPressStart = millis();
    }

    unsigned long holdTime = millis() - buttonPressStart;

    if (holdTime > fullSpeedTime) {
      holdTime = fullSpeedTime;
    }

    int currentDelay = slowDelay - ((slowDelay - fastDelay) * holdTime / fullSpeedTime);

    if (millis() - lastMoveTime >= currentDelay) {
      currentLed = currentLed + 1;
      currentLed = currentLed % LED_COUNT;

      strip.clear();
      strip.setPixelColor(currentLed, strip.Color(0, 0, ledBrightness));
      strip.show();

      Serial.print("LED: ");
      Serial.print(currentLed);
      Serial.print("  Delay: ");
      Serial.println(currentDelay);

      lastMoveTime = millis();
    }
  } else {
    // Button released → RESET everything

    buttonPressStart = 0;
    currentLed = 0;

    strip.clear();
    strip.setPixelColor(currentLed, strip.Color(0, 0, ledBrightness));
    strip.show();

    Serial.println("Reset");
  }
}