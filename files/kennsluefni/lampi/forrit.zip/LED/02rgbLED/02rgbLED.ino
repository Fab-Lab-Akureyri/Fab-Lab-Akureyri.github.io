#include <Adafruit_NeoPixel.h>

#define LED_PIN    21
#define LED_COUNT  13
#define BUTTON_PIN 20

Adafruit_NeoPixel strip(LED_COUNT, LED_PIN, NEO_GRB + NEO_KHZ800);

// Button tracking
int lastButtonState = HIGH;

// Mode (0 = off, 1 = red, 2 = green, 3 = blue)
int mode = 0;

void setup() {
  Serial.begin(9600);

  pinMode(BUTTON_PIN, INPUT_PULLUP);

  strip.begin();
  strip.clear();
  strip.show(); // start with LEDs off
}

void loop() {
  int currentButtonState = digitalRead(BUTTON_PIN);

  // Detect button click
  if (lastButtonState == HIGH && currentButtonState == LOW) {
    mode = mode + 1;

    // Keep mode between 0–3
    if (mode > 3) {
      mode = 0;
    }

    // Change LED based on mode
    if (mode == 0) {
      Serial.println("OFF");
      strip.clear();
    }
    else if (mode == 1) {
      Serial.println("RED");
      strip.fill(strip.Color(10, 0, 0));
    }
    else if (mode == 2) {
      Serial.println("GREEN");
      strip.fill(strip.Color(0, 10, 0));
    }
    else if (mode == 3) {
      Serial.println("BLUE");
      strip.fill(strip.Color(0, 0, 10));
    }

    strip.show();
  }

  lastButtonState = currentButtonState;

  delay(50);
}