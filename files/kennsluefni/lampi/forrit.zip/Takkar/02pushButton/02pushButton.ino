void setup() {
  Serial.begin(9600);

  // Set pin 20 as input with internal pull-up resistor
  pinMode(20, INPUT_PULLUP);
}

void loop() {
  // Read the button state
  int buttonState = digitalRead(20);

  // Check if button is pressed
  if (buttonState == LOW) {
    Serial.println("Button pressed");
  } else {
    Serial.println("Button not pressed");
  }

  delay(500); // small delay so it’s readable
}