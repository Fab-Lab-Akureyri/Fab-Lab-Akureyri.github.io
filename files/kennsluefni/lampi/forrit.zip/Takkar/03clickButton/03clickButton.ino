void setup() {
  Serial.begin(9600);

  pinMode(20, INPUT_PULLUP);
}

// Variable to remember previous button state
int lastButtonState = HIGH;

void loop() {
  int currentButtonState = digitalRead(20);

  // Check if button was just pressed
  if (lastButtonState == HIGH && currentButtonState == LOW) {
    Serial.println("Button clicked");
  }

  // Save current state for next loop
  lastButtonState = currentButtonState;

  delay(50); // small delay to help with stability
}