void setup() {
  Serial.begin(9600);

  pinMode(20, INPUT_PULLUP);
}

// Track button states
int lastButtonState = HIGH;

// Counter variable
int clickCount = 0;

void loop() {
  int currentButtonState = digitalRead(20);

  // Detect button click (HIGH → LOW)
  if (lastButtonState == HIGH && currentButtonState == LOW) {
    clickCount = clickCount + 1;

    Serial.print("Button clicks: ");
    Serial.println(clickCount);
  }

  // Save state for next loop
  lastButtonState = currentButtonState;

  delay(50);
}